#ifndef HEADER_FILE
#define HEADER_FILE

int a_plus_b(int a, int b);
int a_minus_b(int a, int b);
int a_times_b(int a, int b);
int a_divide_b(int a, int b);
int a_modulus_b(int a, int b);

#endif